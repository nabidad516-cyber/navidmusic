# ساخت APK نوید موزیک (بدون نیاز به کامپیوتر)

## روش ۱ — با GitHub (رایگان، فقط با گوشی)
1. در github.com یک حساب بسازید و یک مخزن (Repository) جدید بسازید.
2. همه‌ی فایل‌های این پروژه (از جمله پوشه‌ی `.github`) را در مخزن آپلود کنید.
3. تب **Actions** ← **Build Android APK** ← **Run workflow**.
4. بعد از ~۵ تا ۸ دقیقه، در پایین صفحه‌ی همان اجرا بخش **Artifacts** فایل `navid-music-apk` را دانلود کنید (zip است؛ داخلش `app-debug.apk`).
5. APK را روی گوشی نصب کنید (اجازه‌ی «نصب از منابع ناشناس» لازم است).

## روش ۲ — با کامپیوتر
```
npm install
npm run build
npx cap add android
npx capacitor-assets generate --android
npx cap sync android
cd android && ./gradlew assembleDebug
```
فایل خروجی: `android/app/build/outputs/apk/debug/app-debug.apk`
(نیاز به Node 22، JDK 21 و Android SDK)

## نکات
- برنامه کاملاً آفلاین است (فونت و کتابخانه‌ها داخل APK هستند).
- آهنگ‌های وارد شده داخل خود برنامه ذخیره می‌شوند و بعد از بستن برنامه هم می‌مانند.
- دکمه‌ی Back: پلیر/جستجو را می‌بندد، بعد به خانه برمی‌گردد، بعد برنامه را minimize می‌کند.
