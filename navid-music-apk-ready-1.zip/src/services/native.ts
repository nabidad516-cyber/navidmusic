import { Capacitor } from '@capacitor/core';
import { App as CapApp } from '@capacitor/app';
import { StatusBar, Style } from '@capacitor/status-bar';

/** True only when running inside the installed Android APK (not in a browser). */
export const isNative = Capacitor.isNativePlatform();

/** Dark status bar that matches the app background. Safe no-op in the browser. */
export async function initNativeChrome(color = '#0b0f19') {
  if (!isNative) return;
  try {
    await StatusBar.setOverlaysWebView({ overlay: false });
    await StatusBar.setStyle({ style: Style.Dark });
    await StatusBar.setBackgroundColor({ color });
  } catch (e) {
    console.warn('StatusBar setup failed', e);
  }
}

/**
 * Android hardware/gesture back button.
 * `handler` returns true if it consumed the press (closed a modal, went home...);
 * otherwise the app is sent to background (music keeps playing).
 */
export function registerBackButton(handler: () => boolean): () => void {
  if (!isNative) return () => {};
  const sub = CapApp.addListener('backButton', () => {
    if (!handler()) CapApp.minimizeApp();
  });
  return () => {
    sub.then((s) => s.remove()).catch(() => {});
  };
}
