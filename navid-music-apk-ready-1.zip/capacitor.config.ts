import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.navid.music',
  appName: 'Navid Music',
  webDir: 'dist',
  backgroundColor: '#0b0f19',
  android: {
    allowMixedContent: false,
  },
};

export default config;
